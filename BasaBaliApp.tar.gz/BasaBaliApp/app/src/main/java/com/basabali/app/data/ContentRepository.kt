package com.basabali.app.data

import android.content.res.AssetManager
import org.json.JSONObject
import kotlin.math.max
import kotlin.random.Random

/**
 * Loads the compiled course assets (see tools/build_content.py) and provides
 * the indices the session builder needs:
 *  - sentences by lesson / by word
 *  - headword + usage sentences per word per lesson
 *  - distractor generators for multiple choice, word bank and fill-blank
 */
class ContentRepository(private val assets: AssetManager) {

    val words = LinkedHashMap<String, WordEntry>()
    val patterns = LinkedHashMap<String, PatternEntry>()
    val sentences = ArrayList<Sentence>(9000)
    val sentencesById = HashMap<String, Sentence>(9000)
    val sentencesByLesson = HashMap<Int, List<Sentence>>()
    val sentencesByWord = HashMap<String, MutableList<Sentence>>()
    val sections = ArrayList<SectionMeta>()
    val stories = ArrayList<Story>()
    val chunks = ArrayList<ChunkMeta>()
    val chunksById = HashMap<String, ChunkMeta>()
    val lessonsById = HashMap<Int, LessonMeta>()

    /** Full unit/subunit path (U1 learn, U2 reinforce, U3 cumulative, U4 lesson review, U5 mastery). */
    val path = ArrayList<PathNode>()
    var nodesByLesson: Map<Int, List<PathNode>> = emptyMap()
        private set

    // dictionary lookup indices (tap-a-word popups)
    private var byToken: Map<String, List<String>> = emptyMap()
    private var byFirstToken: Map<String, List<String>> = emptyMap()

    private var loaded = false

    fun ensureLoaded() {
        if (loaded) return
        loadWords()
        loadPatterns()
        loadSentences()
        loadCurriculum()
        loadStories()
        buildIndices()
        buildPath()
        loaded = true
    }

    // ---------------------------------------------------------------- loading

    private fun readJson(name: String): String =
        assets.open("content/$name").bufferedReader(Charsets.UTF_8).use { it.readText() }

    private fun loadWords() {
        val arr = JSONObject(readJson("words.json")).getJSONArray("words")
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val id = o.getString("id")
            words[id] = WordEntry(
                id = id,
                firstLesson = o.getInt("lesson"),
                gloss = o.optString("gloss", id),
                register = o.optString("register", "mider")
            )
        }
    }

    private fun loadPatterns() {
        val arr = JSONObject(readJson("patterns.json")).getJSONArray("patterns")
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val id = o.getString("id")
            patterns[id] = PatternEntry(id, o.optString("name", id), o.getInt("lesson"))
        }
    }

    private fun loadSentences() {
        val arr = JSONObject(readJson("sentences.json")).getJSONArray("sentences")
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val s = Sentence(
                id = o.getString("id"),
                lesson = o.getInt("lesson"),
                num = o.getInt("num"),
                bal = o.getString("bal"),
                en = o.getString("en"),
                tokens = o.getJSONArray("tokens").toStringList(),
                words = o.getJSONArray("words").toStringList(),
                patterns = o.getJSONArray("patterns").toStringList(),
                newItem = o.optString("newItem", "").ifEmpty { null },
                register = o.optString("register", "mider"),
                headword = o.optBoolean("headword", false)
            )
            sentences += s
            sentencesById[s.id] = s
        }
    }

    private fun loadCurriculum() {
        val root = JSONObject(readJson("curriculum.json"))
        val secs = root.getJSONArray("sections")
        for (i in 0 until secs.length()) {
            val so = secs.getJSONObject(i)
            val lessonsJ = so.getJSONArray("lessons")
            val lessons = ArrayList<LessonMeta>()
            for (j in 0 until lessonsJ.length()) {
                val lo = lessonsJ.getJSONObject(j)
                val lid = lo.getInt("id")
                val chunksJ = lo.getJSONArray("chunks")
                val chunkLists = ArrayList<List<String>>()
                for (c in 0 until chunksJ.length()) chunkLists += chunksJ.getJSONArray(c).toStringList()
                val meta = LessonMeta(
                    id = lid,
                    title = lo.getString("title"),
                    section = so.getInt("id"),
                    items = lo.getJSONArray("items").toStringList(),
                    chunks = chunkLists
                )
                lessons += meta
                lessonsById[lid] = meta
                chunkLists.forEachIndexed { idx, items ->
                    val ch = ChunkMeta("L${lid}C$idx", so.getInt("id"), lid, idx, items)
                    chunks += ch
                    chunksById[ch.id] = ch
                }
            }
            sections += SectionMeta(so.getInt("id"), so.getString("title"), lessons)
        }
    }

    private fun loadStories() {
        try {
            val arr = JSONObject(readJson("stories.json")).getJSONArray("stories")
            for (i in 0 until arr.length()) {
                val so = arr.getJSONObject(i)
                val lines = ArrayList<StoryLine>()
                val lj = so.getJSONArray("lines")
                for (j in 0 until lj.length()) {
                    val lo = lj.getJSONObject(j)
                    lines += StoryLine(
                        bal = lo.getString("bal"),
                        en = lo.getString("en"),
                        tokens = lo.getJSONArray("tokens").toStringList(),
                        words = lo.getJSONArray("words").toStringList(),
                        patterns = lo.getJSONArray("patterns").toStringList()
                    )
                }
                val qs = ArrayList<StoryQuestion>()
                val qj = so.getJSONArray("questions")
                for (j in 0 until qj.length()) {
                    val qo = qj.getJSONObject(j)
                    qs += StoryQuestion(
                        prompt = qo.getString("prompt"),
                        line = qo.getInt("line"),
                        options = qo.getJSONArray("options").toStringList(),
                        answer = qo.getInt("answer")
                    )
                }
                stories += Story(
                    id = so.getString("id"),
                    title = so.getString("title"),
                    titleEn = so.getString("titleEn"),
                    gate = so.getInt("gate"),
                    lines = lines,
                    questions = qs
                )
            }
        } catch (_: Exception) {
            // stories are optional content
        }
    }

    fun storyById(id: String): Story? = stories.firstOrNull { it.id == id }

    private fun org.json.JSONArray.toStringList(): List<String> =
        (0 until length()).map { getString(it) }

    private fun buildIndices() {
        buildLookupIndex()
        sentencesByLesson.putAll(sentences.groupBy { it.lesson })
        for (s in sentences) {
            for (w in s.words) {
                sentencesByWord.getOrPut(w) { ArrayList() } += s
            }
        }
    }

    private fun buildPath() {
        path.clear()
        for (sec in sections) {
            for (lesson in sec.lessons) {
                val k = lesson.chunks.size
                for (i in 0 until k) {
                    val ch = chunksById["L${lesson.id}C$i"] ?: continue
                    path += PathNode("L${lesson.id}U1S$i", lesson.id, 1, i, NodeKind.Learn(ch))
                }
                for (i in 0 until k) {
                    val ch = chunksById["L${lesson.id}C$i"] ?: continue
                    path += PathNode("L${lesson.id}U2S$i", lesson.id, 2, i, NodeKind.Learn(ch))
                }
                for (i in 0 until 3) {
                    path += PathNode("L${lesson.id}U3S$i", lesson.id, 3, i, NodeKind.Cumulative(lesson.id, 12))
                }
                val n4 = (lesson.items.size + 9) / 10
                for (i in 0 until n4) {
                    path += PathNode("L${lesson.id}U4S$i", lesson.id, 4, i, NodeKind.LessonReview(lesson.id, 12))
                }
                path += PathNode("L${lesson.id}U5S0", lesson.id, 5, 0, NodeKind.LessonReview(lesson.id, 14))
            }
        }
        nodesByLesson = path.groupBy { it.lessonId }
    }

    private fun buildLookupIndex() {
        val single = HashMap<String, MutableList<String>>()
        val multi = HashMap<String, MutableList<String>>()
        for (id in words.keys) {
            val toks = id.split(" ")
            if (toks.size == 1) single.getOrPut(toks[0]) { ArrayList() } += id
            else multi.getOrPut(toks[0]) { ArrayList() } += id
        }
        byToken = single
        byFirstToken = multi
    }

    /**
     * Dictionary lookup for the token at [index] in a normalized sentence:
     * every vocabulary entry that covers that position (single-word entries —
     * including bases of -ne/-e/-n suffixed forms — plus multi-word entries
     * whose token span includes the position). Powers the tap-a-word popup.
     */
    fun lookupsAt(tokensNorm: List<String>, index: Int): List<WordEntry> {
        if (index !in tokensNorm.indices) return emptyList()
        val out = LinkedHashMap<String, WordEntry>()
        val t = tokensNorm[index]
        val bases = LinkedHashSet<String>()
        bases += t
        for (suf in listOf("ne", "e", "n")) {
            if (t.length > suf.length && t.endsWith(suf)) bases += t.substring(0, t.length - suf.length)
        }
        for (b in bases) {
            byToken[b]?.forEach { id -> words[id]?.let { out.putIfAbsent(id, it) } }
        }
        for (start in 0..index) {
            val ids = byFirstToken[tokensNorm[start]] ?: continue
            for (id in ids) {
                val w = id.split(" ")
                if (start + w.size - 1 < index) continue
                if (start + w.size > tokensNorm.size) continue
                var match = true
                for (k in w.indices) {
                    if (tokensNorm[start + k] != w[k]) { match = false; break }
                }
                if (match) words[id]?.let { out.putIfAbsent(id, it) }
            }
        }
        return out.values.toList()
    }

    // ---------------------------------------------------------------- queries

    fun gloss(id: String): String = words[id]?.gloss ?: id

    fun registerOf(id: String): String = words[id]?.register ?: "mider"

    /** The vocabulary-presentation line for [wordId] inside [lesson] (if any). */
    fun headwordSentence(wordId: String, lesson: Int): Sentence? =
        (sentencesByLesson[lesson] ?: emptyList()).firstOrNull { it.headword && it.tokens.joinToString(" ") == wordId }

    /** Real usage sentences containing [wordId] in [lesson], suitable for exercises. */
    fun usageSentences(wordId: String, lesson: Int, limit: Int = 4): List<Sentence> =
        (sentencesByLesson[lesson] ?: emptyList())
            .filter { !it.headword && it.words.contains(wordId) && it.tokens.size in 2..12 }
            .take(limit)

    /** Any usable sentence containing [wordId] (fallback across lessons). */
    fun anyUsageSentence(wordId: String, limitLesson: Int? = null): Sentence? {
        val list = sentencesByWord[wordId] ?: return null
        return list.firstOrNull { !it.headword && it.tokens.size in 2..12 && (limitLesson == null || it.lesson <= limitLesson) }
    }

    fun lessonNeighbours(lesson: Int): List<Sentence> =
        (sentencesByLesson[max(1, lesson - 1)] ?: emptyList()) +
            (sentencesByLesson[lesson] ?: emptyList()) +
            (sentencesByLesson[lesson + 1] ?: emptyList())

    // ------------------------------------------------------------ distractors

    fun distractorEnglish(s: Sentence, n: Int): List<String> {
        val pool = lessonNeighbours(s.lesson).filter { it.id != s.id && it.en != s.en && it.en.length in 4..70 }
        val picked = pool.distinctBy { it.en }.shuffled().take(n).map { it.en }
        // top-up from anywhere if the neighbourhood is too small
        if (picked.size < n) {
            val extra = sentences.filter { it.id != s.id && it.en != s.en && it.en !in picked && it.en.length in 4..70 }
                .distinctBy { it.en }.shuffled().take(n - picked.size).map { it.en }
            return picked + extra
        }
        return picked
    }

    fun distractorBalinese(s: Sentence, n: Int): List<String> {
        val pool = (sentencesByLesson[s.lesson] ?: emptyList())
            .filter { it.id != s.id && it.bal != s.bal && !it.headword && it.tokens.size in 2..9 }
        val picked = pool.distinctBy { it.bal }.shuffled().take(n).map { it.bal }
        if (picked.size < n) {
            val extra = sentences.filter { it.id != s.id && it.bal != s.bal && !it.headword && it.tokens.size in 2..9 && it.bal !in picked }
                .shuffled().take(n - picked.size).map { it.bal }
            return picked + extra
        }
        return picked
    }

    /** A single extra tile for the word bank, drawn from the same lesson. */
    fun distractorToken(s: Sentence): String? {
        val banned = s.bal.lowercase().split(" ").map { it.trim('.', ',', '!', '?', ';', ':') }.toSet()
        val pool = (sentencesByLesson[s.lesson] ?: emptyList())
            .flatMap { it.bal.split(" ") }
            .map { it.trim('.', ',', '!', '?', ';', ':') }
            .filter { it.length > 2 && it.lowercase() !in banned }
        return pool.randomOrNull()
    }

    /** Wrong options for a fill-blank on [target] (single-token word ids). */
    fun wordDistractors(target: String, s: Sentence, n: Int): List<String> {
        val sameLesson = (sentencesByLesson[s.lesson] ?: emptyList()).flatMap { it.words }.distinct()
        var pool = sameLesson.filter { it != target && !it.contains(' ') }
        if (pool.size < n) {
            pool = (pool + words.keys.filter { !it.contains(' ') && it != target }).distinct()
        }
        return pool.shuffled().take(n)
    }

    // ---------------------------------------------------------------- display

    private val properNouns = setOf(
        "bali", "jawa", "galungan", "kuningan", "nyepi", "saraswati", "siwaratri",
        "om swastiastu", "basa bali", "gunung agung", "idul"
    )

    /** Pretty display of a word id (capitalizes proper nouns, first letter of sentences). */
    fun display(wordId: String): String {
        val parts = wordId.split(" ")
        return if (wordId in properNouns) {
            parts.joinToString(" ") { it.replaceFirstChar { c -> c.uppercaseChar() } }
        } else wordId
    }

    fun shortGloss(gloss: String, max: Int = 30): String {
        val g = gloss.trim()
        if (g.length <= max) return g
        val cut = g.take(max)
        val sp = cut.lastIndexOf(' ')
        return (if (sp > 12) cut.take(sp) else cut) + "…"
    }

    fun random(): Random = Random.Default
}
