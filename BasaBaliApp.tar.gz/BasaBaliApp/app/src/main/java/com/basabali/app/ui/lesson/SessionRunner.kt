package com.basabali.app.ui.lesson

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.basabali.app.data.ContentRepository
import com.basabali.app.data.UserStore
import com.basabali.app.engine.DictationEx
import com.basabali.app.engine.ErrorAttribution
import com.basabali.app.engine.Exercise
import com.basabali.app.engine.FillBlankEx
import com.basabali.app.engine.ListenTapEx
import com.basabali.app.engine.MatchPairsEx
import com.basabali.app.engine.MultipleChoiceEx
import com.basabali.app.engine.SpeakEx
import com.basabali.app.engine.Srs
import com.basabali.app.engine.TextMatch
import com.basabali.app.engine.TypeTranslationEx
import com.basabali.app.engine.WordBankEx
import com.basabali.app.engine.WordCardEx
import java.time.LocalDate
import kotlin.math.max
import kotlin.math.min

/**
 * Runtime state machine for one session.
 *
 * Handles: hearts, grading (tap / build / type / speak), SRS updates for every
 * tag on the exercise, error attribution (word vs pattern blame), in-session
 * re-queue of a downgraded variant after a miss, XP, streaks, quests, league
 * XP and chunk completion.
 */
class SessionRunner(
    initialExercises: List<Exercise>,
    private val content: ContentRepository,
    private val store: UserStore,
    private val nodeId: String?,
    private val onFinish: (SessionResult) -> Unit
) {
    data class Feedback(val ok: Boolean, val correctText: String?, val note: String? = null)

    data class SessionResult(
        val xp: Int,
        val correct: Int,
        val total: Int,
        val failed: Boolean,
        val streak: Int,
        val streakUp: Boolean,
        val questBonus: Int
    )

    private val queue = initialExercises.toMutableList()

    var index by mutableStateOf(0)
        private set
    var hearts by mutableStateOf(5)
        private set
    var correctCount by mutableStateOf(0)
        private set
    var answeredCount by mutableStateOf(0)
        private set
    var feedback by mutableStateOf<Feedback?>(null)
        private set
    var finished by mutableStateOf(false)
        private set

    private val requeued = HashSet<String>()
    private var resultDelivered = false

    val current: Exercise? get() = queue.getOrNull(index)
    val total: Int get() = queue.size
    val progress: Float get() = if (queue.isEmpty()) 0f else index.toFloat() / queue.size.toFloat()

    // ------------------------------------------------------------------ inputs

    /** Word cards are exposure only: register the word as taught, no grading. */
    fun onCardSeen(ex: WordCardEx) {
        val st = store.wordState(ex.wordId)
        if (st.lastReview <= 0L) st.lastReview = System.currentTimeMillis()
    }

    /** Match-pairs is a warm-up: exposure credit, no heart loss. */
    fun onMatchPairsDone(ex: MatchPairsEx, errors: Int) {
        val now = System.currentTimeMillis()
        for (t in ex.tags) updateTag(t, ok = true, now = now)
        answeredCount++
        if (errors == 0) correctCount++
    }

    fun submitChoice(ex: MultipleChoiceEx, choice: String): Boolean =
        grade(ex, choice == ex.correct, ex.correct)

    fun submitListen(ex: ListenTapEx, choice: String): Boolean =
        grade(ex, choice == ex.correct, ex.correct)

    fun submitBlank(ex: FillBlankEx, choice: String): Boolean =
        grade(ex, choice == ex.correct, content.display(ex.correct))

    fun submitBank(ex: WordBankEx, built: List<String>): Boolean {
        val builtLower = built.map { it.lowercase() }
        val ok = builtLower == ex.answerTokens
        val blame = if (!ok) {
            ErrorAttribution.forBank(ex, builtLower, ex.sentenceId?.let { content.sentencesById[it] })
        } else emptyList()
        return grade(ex, ok, ex.answerTokens.joinToString(" "), blame)
    }

    /** E6 dictation / E8 typing: similarity-graded with an "almost" band. */
    fun submitTyped(ex: Exercise, typed: String, answerNorm: String, answerDisplay: String): Boolean {
        val sim = TextMatch.sentenceSimilarity(typed, answerNorm)
        return when {
            sim >= TextMatch.TYPING_EXACT -> grade(ex, true, answerDisplay)
            sim >= TextMatch.TYPING_NEAR -> grade(ex, true, answerDisplay, note = "Almost — watch the spelling")
            else -> grade(ex, false, answerDisplay)
        }
    }

    /** E9 speaking: best ASR hypothesis vs target; generous threshold. */
    fun submitSpeak(ex: SpeakEx, transcripts: List<String>): Boolean {
        if (transcripts.isEmpty()) return false
        var best = 0.0
        var bestText = ""
        for (t in transcripts) {
            val sim = TextMatch.sentenceSimilarity(t, ex.targetNorm)
            if (sim > best) { best = sim; bestText = t }
        }
        val ok = best >= TextMatch.SPEAK_PASS
        val note = if (ok && best < TextMatch.TYPING_EXACT) "Heard: “$bestText”"
                   else if (!ok) "Heard: “$bestText”"
                   else null
        return grade(ex, ok, ex.target, note = note)
    }

    fun continueNext() {
        if (finished) return
        feedback = null
        index++
        if (hearts <= 0 || index >= queue.size) finish()
    }

    // ------------------------------------------------------------------ internals

    private fun grade(
        ex: Exercise,
        ok: Boolean,
        correctText: String,
        blameOverride: List<String>? = null,
        note: String? = null
    ): Boolean {
        if (feedback != null || finished) return ok   // ignore double submits
        val now = System.currentTimeMillis()
        answeredCount++
        ex.sentenceId?.let { store.touchSeen(it, now) }
        if (ok) {
            correctCount++
            for (t in ex.tags) updateTag(t, ok = true, now = now)
            feedback = Feedback(true, null, note)
        } else {
            hearts = max(0, hearts - 1)
            val blame = blameOverride ?: ex.focusTags.ifEmpty { ex.tags }
            for (t in blame) updateTag(t, ok = false, now = now)
            feedback = Feedback(false, correctText, note)
            val sid = ex.sentenceId
            if (sid != null && requeued.add(sid)) {
                downgrade(ex)?.let { easier ->
                    val pos = min(index + 2, queue.size)
                    queue.add(pos, easier)
                }
            }
        }
        return ok
    }

    private fun updateTag(tag: String, ok: Boolean, now: Long) {
        if (tag.startsWith("w:")) {
            val st = store.wordState(tag.substring(2))
            if (ok) Srs.onCorrect(st, now) else Srs.onWrong(st, now)
        } else if (tag.startsWith("p:")) {
            val st = store.patternState(tag.substring(2))
            if (ok) Srs.onCorrect(st, now) else Srs.onWrong(st, now)
        }
    }

    private fun downgrade(ex: Exercise): Exercise? {
        val sid = ex.sentenceId ?: return null
        val s = content.sentencesById[sid] ?: return null
        return when (ex) {
            is WordBankEx, is FillBlankEx, is DictationEx, is TypeTranslationEx, is SpeakEx -> {
                val distr = content.distractorBalinese(s, 2)
                val options = (listOf(s.bal) + distr).distinct().shuffled()
                MultipleChoiceEx(s.en, s.bal, options, false, s.register, s.id, ex.tags, ex.focusTags)
            }
            is ListenTapEx -> {
                // fall back to a readable choice exercise on the same sentence
                val distr = content.distractorEnglish(s, 2)
                val options = (listOf(s.en) + distr).distinct().shuffled()
                MultipleChoiceEx(s.bal, s.en, options, true, s.register, s.id, ex.tags, ex.focusTags)
            }
            is MultipleChoiceEx -> ex.copy(options = ex.options.shuffled())
            else -> null
        }
    }

    private fun finish() {
        if (resultDelivered) return
        resultDelivered = true
        finished = true
        val failed = hearts <= 0

        if (!failed && nodeId != null) store.doneChunks.add(nodeId)

        var streakUp = false
        if (!failed) {
            val today = LocalDate.now().toString()
            val yesterday = LocalDate.now().minusDays(1).toString()
            if (store.lastDayKey != today) {
                streakUp = true
                store.streak = if (store.lastDayKey == yesterday) store.streak + 1 else 1
                store.lastDayKey = today
            }
        }

        val xpGain = correctCount * 2 + (if (!failed) 10 else 0)
        store.xp += xpGain

        var questBonus = 0
        if (!failed) {
            questBonus = store.recordSession(xpGain, lessonsCompleted = 1, perfectAnswers = correctCount)
        }
        store.save()
        onFinish(SessionResult(xpGain + questBonus, correctCount, answeredCount, failed, store.streak, streakUp, questBonus))
    }
}
