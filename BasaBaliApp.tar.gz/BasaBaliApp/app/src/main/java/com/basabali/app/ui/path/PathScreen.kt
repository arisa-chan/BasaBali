package com.basabali.app.ui.path

import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.basabali.app.audio.AsrManager
import com.basabali.app.audio.TtsManager
import com.basabali.app.data.ContentRepository
import com.basabali.app.data.PathNode
import com.basabali.app.data.Story
import com.basabali.app.data.UserStore
import com.basabali.app.engine.LeagueEngine
import com.basabali.app.engine.Quests
import com.basabali.app.engine.SessionBuilder
import com.basabali.app.engine.Srs
import com.basabali.app.ui.theme.CreamCard
import com.basabali.app.ui.theme.Gold
import com.basabali.app.ui.theme.GrayLock
import com.basabali.app.ui.theme.GreenOk
import com.basabali.app.ui.theme.Ink
import com.basabali.app.ui.theme.InkSoft
import com.basabali.app.ui.theme.Teal
import kotlinx.coroutines.launch

private fun unitLabel(unit: Int, lessonId: Int): String = when (unit) {
    1 -> "U1 · Learn"
    2 -> "U2 · Reinforce"
    3 -> "U3 · Review L1–$lessonId"
    4 -> "U4 · Lesson review"
    else -> "U5 · Mastery"
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PathScreen(
    content: ContentRepository,
    store: UserStore,
    builder: SessionBuilder,
    tts: TtsManager?,
    asr: AsrManager?,
    onStartNode: (PathNode) -> Unit,
    onPractice: () -> Unit,
    onLeague: () -> Unit,
    onStory: (Story) -> Unit,
    onPlacement: () -> Unit,
    onReset: () -> Unit
) {
    val context = LocalContext.current
    val now = remember { System.currentTimeMillis() }
    LaunchedEffect(Unit) {
        LeagueEngine.ensureActive(store, now)
    }

    val done = store.doneChunks
    val currentNodeId = remember(done.toSet()) {
        content.path.firstOrNull { it.id !in done }?.id
    }
    val currentLessonId = remember(currentNodeId) {
        content.path.firstOrNull { it.id == currentNodeId }?.lessonId
    }
    val dueCount = remember(done.toSet(), store.xp) { builder.dueCount() }
    val learnedWords = remember(done.toSet(), store.xp) { store.taughtWordCount() }

    val snack = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    var showSettings by remember { mutableStateOf(false) }
    var showResetDialog by remember { mutableStateOf(false) }

    Scaffold(
        snackbarHost = { SnackbarHost(snack) },
        containerColor = MaterialTheme.colorScheme.background
    ) { pad ->
        LazyColumn(
            Modifier
                .fillMaxSize()
                .padding(pad)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // -------------------------------------------------- header
            item {
                Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("BasaBali", fontSize = 26.sp, fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary)
                        Text("Learn Balinese from English", fontSize = 13.sp, color = InkSoft)
                    }
                    HeaderStat("🔥", "${store.streak}")
                    HeaderStat("⭐", "${store.xp}")
                    IconButton(onClick = {
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(
                                Intent.EXTRA_TEXT,
                                "I have a ${store.streak}-day streak and ${store.xp} XP on BasaBali — learning Balinese! 🔥🌺"
                            )
                        }
                        try { context.startActivity(Intent.createChooser(send, "Share progress")) } catch (_: Exception) {}
                    }) { Text("📤", fontSize = 18.sp) }
                    IconButton(onClick = { showSettings = true }) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings", tint = InkSoft)
                    }
                }
            }

            // -------------------------------------------------- practice hub
            item {
                Surface(
                    color = if (dueCount > 0) Teal.copy(alpha = 0.12f) else CreamCard,
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.5.dp, if (dueCount > 0) Teal.copy(alpha = 0.5f) else Color(0x1A000000)),
                    modifier = Modifier.fillMaxWidth().clickable {
                        if (dueCount > 0) onPractice()
                        else scope.launch { snack.showSnackbar("All caught up — nothing due for review yet.") }
                    }
                ) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("🧠", fontSize = 26.sp)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(if (dueCount > 0) "Personalized practice" else "All caught up",
                                fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = Ink)
                            Text(
                                if (dueCount > 0) "$dueCount word/pattern reviews due — SRS picks the sentences"
                                else "Finish a lesson step and come back later",
                                fontSize = 12.sp, color = InkSoft
                            )
                        }
                        if (dueCount > 0) Text("▶", color = Teal, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // -------------------------------------------------- quests
            item {
                val today = Quests.dayKey()
                val defs = Quests.forDay(today)
                val prog = if (store.questDay == today) store.questProg else listOf(0, 0, 0)
                Surface(
                    color = CreamCard, shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, Color(0x14000000)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("🎯 Daily quests", fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                                color = Ink, modifier = Modifier.weight(1f))
                            if (store.questDay == today && store.questBonusClaimed)
                                Text("+30 XP claimed ✓", fontSize = 11.sp, color = GreenOk, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.height(8.dp))
                        defs.forEachIndexed { i, d ->
                            val p = (prog.getOrElse(i) { 0 }).coerceAtMost(d.goal)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(d.label(), fontSize = 13.sp, color = Ink)
                                    Spacer(Modifier.height(3.dp))
                                    LinearProgressIndicator(
                                        progress = { p.toFloat() / d.goal.toFloat() },
                                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                                        color = if (p >= d.goal) GreenOk else Gold,
                                        trackColor = Gold.copy(alpha = 0.12f)
                                    )
                                }
                                Spacer(Modifier.width(10.dp))
                                Text("$p/${d.goal}", fontSize = 11.sp, color = InkSoft)
                            }
                            Spacer(Modifier.height(8.dp))
                        }
                    }
                }
            }

            // -------------------------------------------------- league card
            item {
                val tierIdx = store.league.tier.coerceIn(0, LeagueEngine.TIERS.lastIndex)
                val tierEmoji = listOf("🥉", "🥈", "🥇", "💎", "🏅", "👑")[tierIdx]
                Surface(
                    color = Gold.copy(alpha = 0.10f), shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, Gold.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth().clickable { onLeague() }
                ) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(tierEmoji, fontSize = 28.sp)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text("${LeagueEngine.TIERS[tierIdx]} League", fontSize = 16.sp,
                                fontWeight = FontWeight.SemiBold, color = Ink)
                            Text(
                                "${LeagueEngine.daysLeft(store, now)} day(s) left · you: ${store.league.userXp} XP",
                                fontSize = 12.sp, color = InkSoft
                            )
                        }
                        Text("🏆", fontSize = 22.sp)
                    }
                }
            }

            // -------------------------------------------------- stories
            item {
                Text("📖 Stories", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = InkSoft,
                    modifier = Modifier.padding(top = 6.dp))
            }
            item {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    for (story in content.stories) {
                        val unlocked = content.path.none { it.lessonId <= story.gate && it.id !in done }
                        val completed = story.id in store.completedStories
                        val bg = when {
                            completed -> GreenOk.copy(alpha = 0.14f)
                            unlocked -> CreamCard
                            else -> GrayLock.copy(alpha = 0.10f)
                        }
                        Surface(
                            color = bg, shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(1.dp, if (unlocked && !completed) Gold.copy(alpha = 0.5f) else Color(0x14000000)),
                            modifier = Modifier.width(158.dp).clickable {
                                if (unlocked) onStory(story)
                                else scope.launch { snack.showSnackbar("Finish all lessons up to Lesson ${story.gate} to unlock this story.") }
                            }
                        ) {
                            Column(Modifier.padding(12.dp)) {
                                Text(if (completed) "✅" else if (unlocked) "📖" else "🔒", fontSize = 20.sp)
                                Spacer(Modifier.height(4.dp))
                                Text(story.title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                                    color = Ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(story.titleEn, fontSize = 11.sp, color = InkSoft,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                                if (!unlocked) Text("Lesson ${story.gate}+", fontSize = 10.sp, color = GrayLock)
                            }
                        }
                    }
                }
            }

            // -------------------------------------------------- stats strip
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    MiniStat("${done.size}/${content.path.size}", "steps done", Modifier.weight(1f))
                    MiniStat("$learnedWords", "words seen", Modifier.weight(1f))
                    MiniStat("${content.sentences.size + content.stories.sumOf { it.lines.size }}", "sentence bank", Modifier.weight(1f))
                }
            }

            // -------------------------------------------------- sections → lessons → units → subunits
            for (section in content.sections) {
                item {
                    Text("Section ${section.id} · ${section.title}",
                        fontSize = 15.sp, fontWeight = FontWeight.Bold, color = InkSoft,
                        modifier = Modifier.padding(top = 10.dp))
                }
                for (lesson in section.lessons) {
                    item {
                        val nodes = content.nodesByLesson[lesson.id] ?: emptyList()
                        var expanded by remember(lesson.id) { mutableStateOf(lesson.id == currentLessonId) }
                        val doneCount = nodes.count { it.id in done }
                        Surface(
                            color = CreamCard, shape = RoundedCornerShape(18.dp),
                            border = BorderStroke(1.dp, Color(0x14000000)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(Modifier.padding(14.dp)) {
                                Row(
                                    Modifier.fillMaxWidth().clickable { expanded = !expanded },
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Lesson ${lesson.id} · ${lesson.title}",
                                        fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = Ink,
                                        modifier = Modifier.weight(1f))
                                    Text("$doneCount/${nodes.size}", fontSize = 12.sp,
                                        color = if (doneCount == nodes.size && nodes.isNotEmpty()) GreenOk else InkSoft)
                                    Spacer(Modifier.width(6.dp))
                                    Text(if (expanded) "▲" else "▼", fontSize = 10.sp, color = InkSoft)
                                }
                                if (expanded) {
                                    Spacer(Modifier.height(10.dp))
                                    for (u in 1..5) {
                                        val unitNodes = nodes.filter { it.unit == u }
                                        if (unitNodes.isEmpty()) continue
                                        Row(
                                            Modifier.fillMaxWidth().padding(bottom = 8.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(unitLabel(u, lesson.id), fontSize = 10.sp, color = InkSoft,
                                                fontWeight = FontWeight.SemiBold, modifier = Modifier.width(104.dp))
                                            FlowRow(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                unitNodes.forEach { node ->
                                                    val state = when {
                                                        node.id in done -> "done"
                                                        node.id == currentNodeId -> "current"
                                                        else -> "locked"
                                                    }
                                                    ChipForNode(node, state) {
                                                        when (state) {
                                                            "locked" -> scope.launch {
                                                                snack.showSnackbar("Finish the previous step first — the path unlocks step by step.")
                                                            }
                                                            else -> onStartNode(node)
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // -------------------------------------------------- settings dialog
    if (showSettings) {
        AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text("Settings") },
            text = {
                Column {
                    Text("Spaced-repetition scheduler", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Ink)
                    Spacer(Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth().clickable {
                            store.schedulerMode = 0; Srs.mode = Srs.Mode.LEITNER; store.save()
                        }) {
                        RadioButton(selected = store.schedulerMode == 0, onClick = {
                            store.schedulerMode = 0; Srs.mode = Srs.Mode.LEITNER; store.save()
                        })
                        Text("Simple — expanding boxes (1→128 days)", fontSize = 13.sp, color = Ink)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth().clickable {
                            store.schedulerMode = 1; Srs.mode = Srs.Mode.FSRS; store.save()
                        }) {
                        RadioButton(selected = store.schedulerMode == 1, onClick = {
                            store.schedulerMode = 1; Srs.mode = Srs.Mode.FSRS; store.save()
                        })
                        Text("FSRS-4.5 — stability/difficulty model", fontSize = 13.sp, color = Ink)
                    }
                    Spacer(Modifier.height(10.dp))
                    Text("Audio", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Ink)
                    Text(
                        "🔊 Voice: Indonesian TTS proxy — " + (if (tts?.available == true) "ready" else "unavailable on this device"),
                        fontSize = 12.sp, color = InkSoft
                    )
                    Text(
                        "🎤 Speech check: Indonesian ASR — " + (if (asr?.available() == true) "ready" else "unavailable on this device"),
                        fontSize = 12.sp, color = InkSoft
                    )
                    Spacer(Modifier.height(10.dp))
                    TextButton(onClick = { showSettings = false; onPlacement() }) {
                        Text("Retake placement test", fontSize = 13.sp)
                    }
                    TextButton(onClick = { showSettings = false; showResetDialog = true }) {
                        Text("Reset all progress", color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showSettings = false }) { Text("Close") }
            }
        )
    }

    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = { Text("Reset all progress?") },
            text = { Text("This clears XP, streak, quests, league, stories, path progress and every word/pattern SRS state on this device.") },
            confirmButton = {
                TextButton(onClick = { showResetDialog = false; onReset() }) {
                    Text("Reset", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = { TextButton(onClick = { showResetDialog = false }) { Text("Keep") } }
        )
    }
}

@Composable
private fun ChipForNode(node: PathNode, state: String, onClick: () -> Unit) {
    val bg = when (state) {
        "done" -> GreenOk.copy(alpha = 0.18f)
        "current" -> Gold
        else -> GrayLock.copy(alpha = 0.12f)
    }
    val fg = when (state) {
        "done" -> GreenOk
        "current" -> Color.White
        else -> GrayLock
    }
    val border = when (state) {
        "done" -> GreenOk.copy(alpha = 0.6f)
        "current" -> Gold
        else -> GrayLock.copy(alpha = 0.35f)
    }
    Surface(
        color = bg,
        shape = CircleShape,
        border = BorderStroke(1.5.dp, border),
        modifier = Modifier.size(38.dp).clickable { onClick() }
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                if (state == "done") "✓" else if (state == "locked") "🔒" else "${node.sub + 1}",
                color = fg,
                fontSize = if (state == "locked") 12.sp else 14.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun HeaderStat(icon: String, value: String) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(end = 8.dp)) {
        Text(icon, fontSize = 16.sp)
        Spacer(Modifier.width(3.dp))
        Text(value, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Ink)
    }
}

@Composable
private fun MiniStat(big: String, small: String, modifier: Modifier = Modifier) {
    Surface(
        color = CreamCard,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, Color(0x14000000)),
        modifier = modifier
    ) {
        Column(Modifier.padding(vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(big, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Ink)
            Text(small, fontSize = 10.sp, color = InkSoft)
        }
    }
}
