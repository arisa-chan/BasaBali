package com.basabali.app.engine

import com.basabali.app.data.RivalState
import com.basabali.app.data.UserStore
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

/**
 * Offline weekly league: 9 generated rivals whose XP accrues at a fixed
 * daily rate since week start; top 3 promote, bottom 2 demote at settlement.
 */
object LeagueEngine {
    val TIERS = listOf("Bronze", "Silver", "Gold", "Sapphire", "Emerald", "Ruby")
    const val USER = "Tiang (You)"
    private const val WEEK_MS = 7L * Srs.DAY_MS

    private val RIVAL_NAMES = listOf(
        "Wayan Sudira", "Made Ari", "Nyoman Suardi", "Ketut Rai", "Putu Oka",
        "Kadek Yuni", "Gede Bagus", "Komang Ayu", "Ayu Saraswati", "Sri Wahyuni",
        "Dewa Agung", "Nyoman Weda", "Ketut Suri", "Made Lenyot", "Wayan Gobleg"
    )

    fun ensureActive(store: UserStore, now: Long) {
        val lg = store.league
        if (lg.weekStart <= 0L || now - lg.weekStart >= WEEK_MS) {
            if (lg.weekStart > 0L) settle(store, now)
            startWeek(store, now)
        }
    }

    private fun settle(store: UserStore, now: Long) {
        val board = standings(store, now)
        val myRank = board.indexOfFirst { it.first == USER } + 1
        store.leagueLastRank = myRank
        val lg = store.league
        when {
            myRank in 1..3 -> {
                lg.tier = min(lg.tier + 1, TIERS.lastIndex)
                store.leaguePromoted = 1
            }
            myRank >= board.size - 1 -> {
                lg.tier = max(lg.tier - 1, 0)
                store.leaguePromoted = 0
            }
            else -> store.leaguePromoted = -1
        }
    }

    private fun startWeek(store: UserStore, now: Long) {
        val r = Random(now)
        val lg = store.league
        lg.weekStart = now
        lg.userXp = 0
        lg.rivals.clear()
        for (n in RIVAL_NAMES.shuffled(r).take(9)) {
            lg.rivals += RivalState(n, (8 + r.nextInt(26)).toDouble())
        }
    }

    fun rivalXp(r: RivalState, weekStart: Long, now: Long): Int {
        val days = max(0L, now - weekStart).toDouble() / Srs.DAY_MS
        val jitter = (r.name.hashCode().let { if (it < 0) -it else it }) % 37
        return (r.ratePerDay * days).toInt() + jitter
    }

    fun standings(store: UserStore, now: Long): List<Pair<String, Int>> {
        val lg = store.league
        val list = lg.rivals.map { it.name to rivalXp(it, lg.weekStart, now) }.toMutableList()
        list += USER to lg.userXp
        list.sortByDescending { it.second }
        return list
    }

    fun daysLeft(store: UserStore, now: Long): Int {
        val end = store.league.weekStart + WEEK_MS
        return max(0, ((end - now) / Srs.DAY_MS).toInt() + 1)
    }

    fun tierName(store: UserStore): String = TIERS[store.league.tier.coerceIn(0, TIERS.lastIndex)]
}
