package com.basabali.app.engine

import com.basabali.app.data.ChunkMeta
import com.basabali.app.data.ContentRepository
import com.basabali.app.data.Sentence
import com.basabali.app.data.UserStore
import kotlin.math.min
import kotlin.random.Random

/** Device/progress capabilities consulted when choosing exercise formats. */
data class Caps(
    val tts: Boolean,             // Indonesian-proxy TTS ready
    val asr: Boolean,             // speech recognition available
    val progressChunks: Int       // completed LEARN subunits — gates listening/typing/speaking
) {
    fun listeningUnlocked(): Boolean = tts && progressChunks >= 2
    fun typingUnlocked(): Boolean = progressChunks >= 8
    fun dictationUnlocked(): Boolean = listeningUnlocked() && progressChunks >= 8
    fun speakUnlocked(): Boolean = asr && progressChunks >= 16
}

/** One placement-test question with the milestone lesson it probes. */
data class PlacementQ(val lesson: Int, val ex: MultipleChoiceEx)

/**
 * Builds exercise sessions, implementing app_design_learning_system.md:
 *
 *  - learn sessions (Units 1–2 of a lesson): ≤5 new items per subunit,
 *    card → recognition → production (+listening once unlocked), review interleaved
 *  - review sessions (practice hub, Unit 3 cumulative, Units 4–5 lesson review):
 *    candidates = sentences whose words are ALL taught; due-based scoring for the
 *    hub, coverage-based scoring for forced lesson/cumulative reviews
 *  - format ladder by tag maturity: choice/listening → word bank → fill-blank/
 *    dictation → typing/speaking
 *  - error attribution (ErrorAttribution): content tile → word blame;
 *    order/function-word → pattern blame
 *  - new-item highlighting: sentences carry `highlight` while their newItem is
 *    still untaught, so first encounters render the word in purple
 */
class SessionBuilder(
    private val content: ContentRepository,
    private val store: UserStore,
    private val random: Random = Random(System.currentTimeMillis())
) {
    companion object {
        const val MAX_SESSION = 18
        const val REVIEW_SLOTS_NEW = 4
        const val REVIEW_SLOTS_PURE = 10
        const val MIN_TOKENS = 2
        const val MAX_TOKENS = 12
        const val MAX_BANK_TOKENS = 10

        val FUNCTION_TOKENS = setOf(
            "di", "ring", "ka", "ke", "lan", "miwah", "tur", "muah",
            "ne", "ba", "ajak", "sareng", "teken", "uli", "saking", "baang"
        )

        val PLACEMENT_MILESTONES = listOf(2, 5, 8, 12, 16, 21, 26, 31, 36, 42, 47, 52, 58, 64)
    }

    fun now(): Long = System.currentTimeMillis()

    fun caps(tts: Boolean, asr: Boolean): Caps =
        Caps(tts, asr, store.learnedCount())

    // ------------------------------------------------------------------ due queries

    fun dueWords(now: Long = now()): Map<String, Double> {
        val out = HashMap<String, Double>()
        for ((id, st) in store.words) {
            if (Srs.isDue(st, now, Srs.TAU_WORD)) out[id] = 1.0 - Srs.pRecall(st, now)
        }
        return out
    }

    fun duePatterns(now: Long = now()): Map<String, Double> {
        val out = HashMap<String, Double>()
        for ((id, st) in store.patterns) {
            if (Srs.isDue(st, now, Srs.TAU_PATTERN)) out[id] = 1.0 - Srs.pRecall(st, now)
        }
        return out
    }

    fun dueCount(): Int {
        val n = now()
        return dueWords(n).size + duePatterns(n).size
    }

    // ------------------------------------------------------------------ learn session (Units 1 & 2)

    fun newChunkSession(chunk: ChunkMeta, caps: Caps): List<Exercise> {
        val out = ArrayList<Exercise>()
        val items = chunk.items
        val lesson = chunk.lessonId

        // E2 warm-up: match pairs — only when every gloss HEAD is unique on the board
        // ("yes" vs "yes (true)" vs "correct/yes" are indistinguishable for beginners;
        // ambiguous items are dropped and the set falls through to flashcards).
        if (items.size >= 3) {
            val cand = items.shuffled(random).map { it to content.shortGloss(content.gloss(it), 26) }
            val headCount = HashMap<String, Int>()
            for ((_, g) in cand) {
                val h = glossHead(g)
                headCount[h] = (headCount[h] ?: 0) + 1
            }
            val pairs = ArrayList<Pair<String, String>>()
            val usedHeads = HashSet<String>()
            for ((id, g) in cand) {
                val h = glossHead(g)
                if ((headCount[h] ?: 0) == 1 && usedHeads.add(h)) pairs += id to g
                if (pairs.size >= 5) break
            }
            if (pairs.size >= 3) out += MatchPairsEx(pairs)
        }

        // Per item: card → recognition (E3) → production (E4) → listening (E5)
        for (item in items) {
            val usages = content.usageSentences(item, lesson, 4)
            val example = usages.firstOrNull() ?: content.anyUsageSentence(item, lesson)
            out += WordCardEx(
                wordId = item,
                gloss = content.gloss(item),
                register = content.registerOf(item),
                exampleBal = example?.bal ?: content.display(item),
                exampleEn = example?.en ?: content.gloss(item)
            )
            val s1 = usages.getOrNull(0)
            if (s1 != null) out += makeChoice(s1, toEnglish = true, focus = listOf("w:$item"))

            val s2 = usages.getOrNull(1) ?: usages.getOrNull(0)
            if (s2 != null) {
                if (s2.tokens.size in MIN_TOKENS..MAX_BANK_TOKENS) out += makeBank(s2, listOf("w:$item"))
                else out += makeChoice(s2, toEnglish = false, focus = listOf("w:$item"))
            }
            val s3 = usages.getOrNull(2)
            if (s3 != null && caps.listeningUnlocked()) {
                out += makeListenTap(s3, toEnglish = true, focus = listOf("w:$item"))
            }
        }

        val exclude = out.mapNotNull { it.sentenceId }.toSet()
        val review = buildReview(REVIEW_SLOTS_NEW, exclude, caps)
        val merged = interleave(out, review)
        return if (merged.size > MAX_SESSION + 2) merged.take(MAX_SESSION + 2) else merged
    }

    private fun glossHead(g: String): String {
        var h = g.lowercase()
        var cut = h.length
        for (ch in listOf('/', '(')) {
            val i = h.indexOf(ch)
            if (i in 1 until cut) cut = i
        }
        h = h.substring(0, cut)
        return h.trim().trim('.').trim()
    }

    // ------------------------------------------------------------------ due-based review (practice hub)

    fun reviewSession(caps: Caps, maxSlots: Int = REVIEW_SLOTS_PURE): List<Exercise> =
        buildReview(maxSlots, emptySet(), caps)

    private fun buildReview(maxSlots: Int, exclude: Set<String>, caps: Caps): List<Exercise> {
        val now = now()
        val dw = dueWords(now).toMutableMap()
        val dp = duePatterns(now).toMutableMap()
        val out = ArrayList<Exercise>()
        val used = exclude.toMutableSet()
        var guard = 0

        while (out.size < maxSlots && (dw.isNotEmpty() || dp.isNotEmpty()) && guard < 80) {
            guard++
            val scored = ArrayList<Triple<Sentence, Double, List<String>>>(24)
            for (s in content.sentences) {
                if (s.headword) continue
                if (s.tokens.size !in MIN_TOKENS..MAX_TOKENS) continue
                if (s.id in used) continue
                if (s.words.isEmpty()) continue
                var taughtAll = true
                for (w in s.words) {
                    if (!store.isTaught(w)) { taughtAll = false; break }
                }
                if (!taughtAll) continue
                var score = 0.0
                val focus = ArrayList<String>(4)
                for (w in s.words) {
                    val d = dw[w]
                    if (d != null) { score += d; focus += "w:$w" }
                }
                for (p in s.patterns) {
                    val d = dp[p]
                    if (d != null) { score += 1.5 * d; focus += "p:$p" }
                }
                if (focus.isEmpty()) continue
                val last = store.seenSentences[s.id] ?: 0L
                score += min(0.3, (now - last).toDouble() / (10.0 * Srs.DAY_MS))
                score -= 0.02 * s.tokens.size
                scored += Triple(s, score, focus)
            }
            if (scored.isEmpty()) break
            scored.sortByDescending { it.second }
            val pick = scored[random.nextInt(min(3, scored.size))]
            val s = pick.first
            val focus = pick.third
            used += s.id
            val ex = formatFor(s, focus, caps)
            if (ex == null) continue
            out += ex
            for (t in focus) {
                if (t.startsWith("w:")) dw.remove(t.substring(2)) else dp.remove(t.substring(2))
            }
        }
        return out
    }

    // ------------------------------------------------------------------ forced reviews (Units 3–5)

    /** Unit 3 — cumulative review of everything taught from Lesson 1 up to [upToLesson]. */
    fun cumulativeReviewSession(upToLesson: Int, maxSlots: Int, caps: Caps): List<Exercise> {
        val focus = store.words.keys
            .filter { (content.words[it]?.firstLesson ?: Int.MAX_VALUE) <= upToLesson }
            .toSet()
        return forcedReview({ l -> l <= upToLesson }, focus, maxSlots, caps)
    }

    /** Units 4–5 — review covering every entry of one lesson. */
    fun lessonReviewSession(lessonId: Int, maxSlots: Int, caps: Caps): List<Exercise> {
        val focus = (content.lessonsById[lessonId]?.items ?: emptyList())
            .filter { store.isTaught(it) }
            .toSet()
        return forcedReview({ l -> l == lessonId }, focus, maxSlots, caps)
    }

    /**
     * Coverage-driven review: repeatedly pick the sentence covering the most
     * not-yet-covered focus words (weakest first), then top up with due-based
     * review so the session is never short.
     */
    private fun forcedReview(
        inScope: (Int) -> Boolean,
        focusWords: Set<String>,
        maxSlots: Int,
        caps: Caps
    ): List<Exercise> {
        val now = now()
        val remaining = focusWords.toMutableSet()
        val out = ArrayList<Exercise>()
        val used = HashSet<String>()
        var guard = 0

        while (out.size < maxSlots && remaining.isNotEmpty() && guard < 150) {
            guard++
            val scored = ArrayList<Triple<Sentence, Double, List<String>>>(32)
            for (s in content.sentences) {
                if (s.headword || !inScope(s.lesson) || s.id in used) continue
                if (s.tokens.size !in MIN_TOKENS..MAX_TOKENS || s.words.isEmpty()) continue
                var taughtAll = true
                for (w in s.words) {
                    if (!store.isTaught(w)) { taughtAll = false; break }
                }
                if (!taughtAll) continue
                val covered = s.words.filter { it in remaining }
                if (covered.isEmpty()) continue
                var score = covered.size * 2.0
                for (w in covered) score += 1.0 / (1.0 + tagMaturity("w:$w"))
                val last = store.seenSentences[s.id] ?: 0L
                score += min(0.3, (now - last).toDouble() / (10.0 * Srs.DAY_MS))
                score -= 0.02 * s.tokens.size
                scored += Triple(s, score, covered.map { "w:$it" })
            }
            if (scored.isEmpty()) break
            scored.sortByDescending { it.second }
            val pick = scored[random.nextInt(min(3, scored.size))]
            val s = pick.first
            used += s.id
            val coveredIds = pick.third.map { it.substring(2) }
            remaining.removeAll(coveredIds.toSet())
            val ex = formatFor(s, pick.third, caps)
            if (ex == null) continue
            out += ex
        }
        if (out.size < maxSlots) {
            out += buildReview(maxSlots - out.size, used, caps)
        }
        return out
    }

    // ------------------------------------------------------------------ format ladder & factories

    private fun formatFor(s: Sentence, focus: List<String>, caps: Caps): Exercise? {
        var mat = Int.MAX_VALUE
        for (t in focus) {
            val m = tagMaturity(t)
            if (m < mat) mat = m
        }
        if (mat == Int.MAX_VALUE) mat = 0
        return when {
            mat <= 1 ->
                if (caps.listeningUnlocked() && random.nextInt(100) < 35)
                    makeListenTap(s, toEnglish = true, focus = focus)
                else makeChoice(s, toEnglish = true, focus = focus)
            mat <= 3 ->
                if (s.tokens.size in MIN_TOKENS..MAX_BANK_TOKENS) makeBank(s, focus)
                else makeChoice(s, toEnglish = false, focus = focus)
            mat <= 5 ->
                if (caps.dictationUnlocked() && s.tokens.size in MIN_TOKENS..8 && random.nextInt(100) < 40)
                    makeDictation(s, focus)
                else makeFillBlank(s, focus) ?: makeBank(s, focus)
            else ->
                if (caps.speakUnlocked() && s.tokens.size in MIN_TOKENS..8 && random.nextInt(100) < 25)
                    makeSpeak(s, focus)
                else if (caps.typingUnlocked() && s.tokens.size in MIN_TOKENS..MAX_BANK_TOKENS)
                    makeType(s, focus)
                else makeFillBlank(s, focus) ?: makeBank(s, focus)
        }
    }

    fun tagMaturity(tag: String): Int {
        val st = if (tag.startsWith("w:")) store.words[tag.substring(2)]
                 else store.patterns[tag.substring(2)]
        return st?.successes ?: 0
    }

    private fun allTags(s: Sentence): List<String> =
        s.words.map { "w:$it" } + s.patterns.map { "p:$it" }

    /** Purple-highlight the sentence's new entry only while it is still untaught. */
    private fun highlightFor(s: Sentence): String? =
        s.newItem?.takeIf { !store.isTaught(it) }

    fun makeChoice(s: Sentence, toEnglish: Boolean, focus: List<String>): Exercise {
        return if (toEnglish) {
            val distr = content.distractorEnglish(s, 2)
            val options = (listOf(s.en) + distr).distinct().shuffled(random)
            MultipleChoiceEx(s.bal, s.en, options, true, s.register, s.id, allTags(s), focus, highlightFor(s))
        } else {
            val distr = content.distractorBalinese(s, 2)
            val options = (listOf(s.bal) + distr).distinct().shuffled(random)
            MultipleChoiceEx(s.en, s.bal, options, false, s.register, s.id, allTags(s), focus, null)
        }
    }

    fun makeBank(s: Sentence, focus: List<String>): Exercise {
        val answer = s.bal.split(" ").filter { it.isNotBlank() }
        val answerLower = answer.map { it.lowercase() }
        val bank = answer.toMutableList()
        content.distractorToken(s)?.let { bank += it }
        bank.shuffle(random)
        return WordBankEx(s.en, answerLower, bank, s.register, s.id, allTags(s), focus, highlightFor(s))
    }

    fun makeFillBlank(s: Sentence, focus: List<String>): Exercise? {
        val focusWords = focus.filter { it.startsWith("w:") }.map { it.substring(2) }
            .filter { !it.contains(' ') }
        val target = focusWords.firstOrNull { containsToken(s, it) }
            ?: s.words.firstOrNull { !it.contains(' ') && containsToken(s, it) }
            ?: return null
        val toks = s.bal.split(" ")
        val idx = toks.indexOfFirst { it.lowercase().trim('.', ',', '!', '?', ';', ':') == target }
        if (idx < 0) return null
        val before = toks.subList(0, idx).joinToString(" ")
        val after = toks.subList(idx + 1, toks.size).joinToString(" ")
        val distr = content.wordDistractors(target, s, 3).filter { it != target }
        val options = (listOf(target) + distr).distinct().shuffled(random)
        if (options.size < 2) return null
        return FillBlankEx(before, after, target, options, s.en, s.register, s.id, allTags(s), focus, highlightFor(s))
    }

    fun makeListenTap(s: Sentence, toEnglish: Boolean, focus: List<String>): Exercise {
        return if (toEnglish) {
            val distr = content.distractorEnglish(s, 2)
            val options = (listOf(s.en) + distr).distinct().shuffled(random)
            ListenTapEx(s.bal, s.en, options, true, s.register, s.id, allTags(s), focus)
        } else {
            val distr = content.distractorBalinese(s, 2)
            val options = (listOf(s.bal) + distr).distinct().shuffled(random)
            ListenTapEx(s.bal, s.bal, options, false, s.register, s.id, allTags(s), focus)
        }
    }

    fun makeDictation(s: Sentence, focus: List<String>): Exercise =
        DictationEx(
            audioText = s.bal,
            answerNorm = TextMatch.normalize(s.bal),
            answerDisplay = s.bal,
            en = s.en,
            register = s.register,
            sentenceId = s.id,
            tags = allTags(s),
            focusTags = focus
        )

    fun makeType(s: Sentence, focus: List<String>): Exercise =
        TypeTranslationEx(
            promptEn = s.en,
            answerNorm = TextMatch.normalize(s.bal),
            answerDisplay = s.bal,
            register = s.register,
            sentenceId = s.id,
            tags = allTags(s),
            focusTags = focus
        )

    fun makeSpeak(s: Sentence, focus: List<String>): Exercise =
        SpeakEx(
            target = s.bal,
            targetNorm = TextMatch.normalize(s.bal),
            en = s.en,
            register = s.register,
            sentenceId = s.id,
            tags = allTags(s),
            focusTags = focus
        )

    private fun containsToken(s: Sentence, wordId: String): Boolean =
        s.bal.split(" ").any { it.lowercase().trim('.', ',', '!', '?', ';', ':') == wordId }

    private fun interleave(main: List<Exercise>, review: List<Exercise>): List<Exercise> {
        if (review.isEmpty()) return main
        val out = ArrayList<Exercise>(main.size + review.size)
        var ri = 0
        var count = 0
        for (ex in main) {
            out += ex
            count++
            if (ri < review.size && count % 4 == 0) { out += review[ri]; ri++ }
        }
        while (ri < review.size) { out += review[ri]; ri++ }
        return out
    }

    // ------------------------------------------------------------------ placement test

    /**
     * 14 milestone probes across the course (Balinese → English recognition).
     * Prefers sentences that introduce a new entry, but any well-sized non-headword
     * sentence of the milestone lesson qualifies — `newItem` is usually set only on
     * the headword line, so requiring it starved the test down to ~4 questions.
     */
    fun placementQuestions(): List<PlacementQ> {
        val out = ArrayList<PlacementQ>()
        for (ml in PLACEMENT_MILESTONES) {
            val lessonSents = content.sentencesByLesson[ml] ?: emptyList()
            val pool = lessonSents.filter {
                !it.headword && it.tokens.size in 3..9 && it.en.length in 8..70
            }
            val s = pool.filter { it.newItem != null }.randomOrNull(random)
                ?: pool.randomOrNull(random)
                ?: lessonSents.filter { !it.headword && it.tokens.size in 2..12 }.randomOrNull(random)
                ?: continue
            out += PlacementQ(
                ml,
                makeChoice(s, toEnglish = true, focus = listOfNotNull(s.newItem?.let { "w:$it" })) as MultipleChoiceEx
            )
        }
        return out
    }

    /** Highest milestone lesson justified by the answers (≥60% cumulative & milestone correct). */
    fun placementFrontier(results: List<Pair<Int, Boolean>>): Int {
        var frontier = 0
        var correct = 0
        var seen = 0
        for ((lesson, ok) in results.sortedBy { it.first }) {
            seen++
            if (ok) correct++
            val acc = correct.toDouble() / seen
            if (ok && acc >= 0.6) frontier = lesson
        }
        return frontier
    }

    /** Mark every path node of lessons ≤ frontier done; seed mid-strength SRS states. */
    fun applyPlacement(frontierLesson: Int) {
        if (frontierLesson <= 0) return
        val now = now()
        for (node in content.path) {
            if (node.lessonId <= frontierLesson) store.doneChunks.add(node.id)
        }
        for (lesson in content.lessonsById.values) {
            if (lesson.id > frontierLesson) continue
            for (item in lesson.items) {
                val st = store.wordState(item)
                st.successes = maxOf(st.successes, 2)
                st.lastReview = now
                st.box = maxOf(st.box, 3)
                if (st.stability <= 0.0) st.stability = 4.0
                if (st.difficulty <= 0.0) st.difficulty = 5.0
            }
        }
        for (p in content.patterns.values) {
            if (p.firstLesson > frontierLesson) continue
            val st = store.patternState(p.id)
            st.successes = maxOf(st.successes, 2)
            st.lastReview = now
            st.box = maxOf(st.box, 3)
            if (st.stability <= 0.0) st.stability = 6.0
            if (st.difficulty <= 0.0) st.difficulty = 5.0
        }
        store.save()
    }
}

/**
 * Decides WHICH tag to penalize on a wrong word-bank build (doc §5.4):
 *  - right tiles, wrong order          → grammar patterns
 *  - wrong/missing function word       → grammar patterns
 *  - one wrong content word            → that word entry
 *  - anything else                     → the exercise's focus tags
 */
object ErrorAttribution {
    fun forBank(ex: WordBankEx, builtLower: List<String>, sentence: Sentence?): List<String> {
        val answer = ex.answerTokens
        if (builtLower == answer) return emptyList()

        val ac = answer.groupingBy { it }.eachCount()
        val bc = builtLower.groupingBy { it }.eachCount()
        val missing = ArrayList<String>()
        val extra = ArrayList<String>()
        for ((t, c) in ac) {
            val d = c - (bc[t] ?: 0)
            repeat(if (d > 0) d else 0) { missing += t }
        }
        for ((t, c) in bc) {
            val d = c - (ac[t] ?: 0)
            repeat(if (d > 0) d else 0) { extra += t }
        }

        val pats = sentence?.patterns?.map { "p:$it" } ?: emptyList()
        return when {
            missing.isEmpty() && extra.isEmpty() ->
                if (pats.isNotEmpty()) pats else ex.focusTags
            (missing + extra).any { it in SessionBuilder.FUNCTION_TOKENS } ->
                if (pats.isNotEmpty()) pats else ex.focusTags
            missing.size == 1 -> {
                val wid = sentence?.words?.firstOrNull { w -> w.split(" ").contains(missing[0]) }
                if (wid != null) listOf("w:$wid") else ex.focusTags
            }
            else -> ex.focusTags
        }
    }
}
