package com.basabali.app.ui.lesson

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.basabali.app.audio.AsrManager
import com.basabali.app.audio.TtsManager
import com.basabali.app.data.ContentRepository
import com.basabali.app.engine.DictationEx
import com.basabali.app.engine.FillBlankEx
import com.basabali.app.engine.ListenTapEx
import com.basabali.app.engine.MatchPairsEx
import com.basabali.app.engine.MultipleChoiceEx
import com.basabali.app.engine.SpeakEx
import com.basabali.app.engine.TypeTranslationEx
import com.basabali.app.engine.WordBankEx
import com.basabali.app.engine.WordCardEx
import com.basabali.app.ui.theme.Gold
import com.basabali.app.ui.theme.GreenOk
import com.basabali.app.ui.theme.Ink
import com.basabali.app.ui.theme.InkSoft
import com.basabali.app.ui.theme.RedBad

@Composable
fun LessonScreen(
    runner: SessionRunner,
    content: ContentRepository,
    tts: TtsManager?,
    asr: AsrManager?,
    onExit: () -> Unit
) {
    val ex = runner.current
    // per-exercise interaction state, reset whenever the queue index changes
    var pickedChoice by remember(runner.index) { mutableStateOf<String?>(null) }
    var bankSelected by remember(runner.index) { mutableStateOf<List<Int>>(emptyList()) }
    var typedText by remember(runner.index) { mutableStateOf("") }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp)
    ) {
        // ------------------------------------------------ top bar
        Row(
            Modifier.fillMaxWidth().padding(top = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onExit) {
                Icon(Icons.Default.Close, contentDescription = "Exit lesson", tint = InkSoft)
            }
            LinearProgressIndicator(
                progress = { runner.progress },
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 10.dp)
                    .height(10.dp)
                    .clip(RoundedCornerShape(5.dp)),
                color = Gold,
                trackColor = Gold.copy(alpha = 0.15f)
            )
            Text("♥ ${runner.hearts}", color = RedBad, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }

        Spacer(Modifier.height(14.dp))

        // ------------------------------------------------ exercise area
        Box(Modifier.weight(1f)) {
            when (val e = ex) {
                null -> Unit

                is WordCardEx -> WordCardView(e, content, tts) {
                    runner.onCardSeen(e)
                    runner.continueNext()
                }

                is MatchPairsEx -> MatchPairsView(e, content, tts) { errs ->
                    runner.onMatchPairsDone(e, errs)
                    runner.continueNext()
                }

                is MultipleChoiceEx -> MultipleChoiceView(
                    ex = e,
                    content = content,
                    tts = tts,
                    enabled = runner.feedback == null && pickedChoice == null,
                    picked = pickedChoice
                ) { choice ->
                    pickedChoice = choice
                    runner.submitChoice(e, choice)
                }

                is ListenTapEx -> ListenTapView(
                    ex = e,
                    tts = tts,
                    enabled = runner.feedback == null && pickedChoice == null,
                    picked = pickedChoice
                ) { choice ->
                    pickedChoice = choice
                    runner.submitListen(e, choice)
                }

                is FillBlankEx -> FillBlankView(
                    ex = e,
                    content = content,
                    tts = tts,
                    enabled = runner.feedback == null && pickedChoice == null,
                    picked = pickedChoice
                ) { choice ->
                    pickedChoice = choice
                    runner.submitBlank(e, choice)
                }

                is WordBankEx -> WordBankView(
                    ex = e,
                    selected = bankSelected,
                    enabled = runner.feedback == null,
                    onPickBank = { i -> bankSelected = bankSelected + i },
                    onRemoveAnswer = { i -> bankSelected = bankSelected - i }
                )

                is DictationEx -> DictationView(
                    ex = e,
                    tts = tts,
                    text = typedText,
                    onText = { typedText = it },
                    enabled = runner.feedback == null
                )

                is TypeTranslationEx -> TypeTranslationView(
                    ex = e,
                    text = typedText,
                    onText = { typedText = it },
                    enabled = runner.feedback == null
                )

                is SpeakEx -> SpeakView(
                    ex = e,
                    tts = tts,
                    asr = asr,
                    enabled = runner.feedback == null,
                    graded = runner.feedback != null,
                    onResult = { res -> if (res.isNotEmpty()) runner.submitSpeak(e, res) },
                    onSkip = { runner.continueNext() }
                )
            }
        }

        // ------------------------------------------------ bottom: check / feedback
        val fb = runner.feedback
        val bank = ex as? WordBankEx
        val dict = ex as? DictationEx
        val typ = ex as? TypeTranslationEx

        if (fb == null && bank != null) {
            Button(
                onClick = {
                    val built = bankSelected.map { bank.bankTokens[it] }
                    runner.submitBank(bank, built)
                },
                enabled = bankSelected.isNotEmpty(),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)
            ) {
                Text("Check", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            }
        }

        if (fb == null && (dict != null || typ != null)) {
            Button(
                onClick = {
                    if (dict != null) runner.submitTyped(dict, typedText, dict.answerNorm, dict.answerDisplay)
                    else if (typ != null) runner.submitTyped(typ, typedText, typ.answerNorm, typ.answerDisplay)
                },
                enabled = typedText.isNotBlank(),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)
            ) {
                Text("Check", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            }
        }

        if (fb != null) {
            val c = if (fb.ok) GreenOk else RedBad
            // Balinese answer worth showing (tappable + speakable)
            val balAnswer: String? = when (val e0 = ex) {
                is WordBankEx -> e0.answerTokens.joinToString(" ")
                is DictationEx -> e0.answerDisplay
                is TypeTranslationEx -> e0.answerDisplay
                is SpeakEx -> e0.target
                is MultipleChoiceEx -> if (!e0.toEnglish) e0.correct else null
                is ListenTapEx -> if (!e0.toEnglish) e0.correct else null
                else -> null
            }
            val showBal = balAnswer != null && (!fb.ok || fb.note != null)
            Surface(
                color = c.copy(alpha = 0.14f),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, c.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(14.dp)) {
                    Text(
                        if (fb.ok) "Sadu! Correct ✨" else "Not quite…",
                        color = c,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    if (fb.note != null) {
                        Spacer(Modifier.height(2.dp))
                        Text(fb.note!!, color = InkSoft, fontSize = 13.sp, fontStyle = FontStyle.Italic)
                    }
                    if (showBal && balAnswer != null) {
                        Spacer(Modifier.height(6.dp))
                        Text("Answer:", fontSize = 12.sp, color = InkSoft)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.weight(1f)) {
                                TappableBalinese(balAnswer, content, null,
                                    fontSize = 16.sp, fontWeight = FontWeight.Normal)
                            }
                            if (tts != null) SpeakerButton(balAnswer, tts, size = 36)
                        }
                    } else if (!fb.ok && fb.correctText != null) {
                        Spacer(Modifier.height(4.dp))
                        Text("Answer:  ${fb.correctText}", color = Ink, fontSize = 14.sp)
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Button(
                onClick = { runner.continueNext() },
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = c),
                modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)
            ) {
                Text("Continue", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
            }
        }
    }
}
