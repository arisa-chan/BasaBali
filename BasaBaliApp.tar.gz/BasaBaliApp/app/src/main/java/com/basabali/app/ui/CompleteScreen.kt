package com.basabali.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.basabali.app.ui.lesson.SessionRunner
import com.basabali.app.ui.theme.Gold
import com.basabali.app.ui.theme.GreenOk
import com.basabali.app.ui.theme.Ink
import com.basabali.app.ui.theme.InkSoft
import com.basabali.app.ui.theme.RedBad

@Composable
fun CompleteScreen(
    result: SessionRunner.SessionResult,
    canRetry: Boolean,
    onContinue: () -> Unit,
    onRetry: () -> Unit
) {
    val acc = if (result.total > 0) (result.correct * 100 / result.total) else 0

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(if (result.failed) "💔" else "🎉", fontSize = 64.sp)
        Spacer(Modifier.height(16.dp))
        Text(
            if (result.failed) "Kehabisan hati — out of hearts!" else "Puput! Lesson complete!",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = if (result.failed) RedBad else GreenOk,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(8.dp))
        Text(
            if (result.failed) "Mistakes shorten the memory — try the session again."
            else if (result.streakUp) "Streak up: ${result.streak} day${if (result.streak == 1) "" else "s"} 🔥"
            else "Keep the streak alive tomorrow 🔥",
            fontSize = 14.sp,
            color = InkSoft,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(28.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatPill("⭐ +${result.xp}", "XP earned")
            StatPill("${acc}%", "accuracy")
            StatPill("${result.correct}/${result.total}", "correct")
        }

        Spacer(Modifier.height(36.dp))

        if (result.failed && canRetry) {
            Button(
                onClick = onRetry,
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                modifier = Modifier.fillMaxWidth()
            ) { Text("Try again", fontSize = 16.sp, fontWeight = FontWeight.SemiBold) }
            Spacer(Modifier.height(10.dp))
        }
        OutlinedButton(
            onClick = onContinue,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (result.failed) "Back to path" else "Continue", fontSize = 16.sp) }
    }
}

@Composable
private fun StatPill(big: String, small: String) {
    Surface(
        color = Gold.copy(alpha = 0.12f),
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Gold.copy(alpha = 0.4f))
    ) {
        Column(
            Modifier.padding(horizontal = 18.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(big, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Ink)
            Text(small, fontSize = 11.sp, color = InkSoft)
        }
    }
}
